$(function(){

	// Andoridでお知らせ下部が見切れるので疑似ブロック要素を挿入
	if(navigator.userAgent.indexOf('Android') !== -1) {
		$('body').append('<span class="hightForAndroid">');
	}

	// 個別装備のスライドトグルメニュー
	var $dispSwitch = $('.dispSwitch');
	var $dispArea = $('.dispArea');
	var closeTxt = 'Close';
	var dispTxt = '';
	
	// 相性性能のスライドトグルメニュー
	var $dispPsvSwitch = $('.dispPsvSwitch');
	var $dispPsvArea = $('.dispPsvArea');
	var $dispPsvTxt = '';

	var _touch = ('ontouchover' in document) ? 'touchstart' : 'click';
	
	$dispSwitch.on(_touch, function() {
		
		if($(this).hasClass('open')) {
			$(this).removeClass('open');
			$(this).next($dispArea).stop(true, true).slideUp(function() {
				dispTxt = $(this).prev($dispSwitch).attr('data-title');
				$(this).prev($dispSwitch).text(dispTxt);
			});
		} else {
			dispTxt = $(this).text();
			$(this).attr('data-title', dispTxt);
			$(this).addClass('open');
			$(this).next($dispArea).stop(true, true).slideDown(function() {
				$(this).prev($dispSwitch).text(closeTxt);
			});
		}
	});

	$dispPsvSwitch.on(_touch, function() {
		
		if($(this).hasClass('open')) {
			$(this).removeClass('open');
			$(this).next($dispPsvArea).stop(true, true).slideUp(function() {
			});
		} else {
			dispPsvTxt = $(this).text();
			$(this).attr('data-title', dispPsvTxt);
			$(this).addClass('open');
			$(this).next($dispPsvArea).stop(true, true).slideDown(function() {
			});
		}
	});
});
